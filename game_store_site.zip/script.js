const games = [
  {
    id: 1,
    title: "Cyberpunk 2077",
    description: "Футуристический RPG с открытым миром",
    price: 1999,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg"
  },
  {
    id: 2,
    title: "The Witcher 3",
    description: "Эпическое фэнтези RPG",
    price: 1499,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg"
  },
  {
    id: 3,
    title: "Minecraft",
    description: "Песочница с бесконечными возможностями",
    price: 899,
    image: "https://upload.wikimedia.org/wikipedia/en/5/51/Minecraft_cover.png"
  },
  {
    id: 4,
    title: "Among Us",
    description: "Мультиплеерная игра на социальное обман",
    price: 299,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/945360/header.jpg"
  }
];

const gamesList = document.getElementById("games-list");
const cartButton = document.getElementById("cart-button");
const cartSection = document.getElementById("cart");
const cartItemsList = document.getElementById("cart-items");
const totalPriceEl = document.getElementById("total-price");
const cartCount = document.getElementById("cart-count");
const closeCartBtn = document.getElementById("close-cart");

let cart = [];

function renderGames() {
  gamesList.innerHTML = "";
  games.forEach(game => {
    const card = document.createElement("div");
    card.className = "game-card";
    card.innerHTML = `
      <img src="${game.image}" alt="${game.title}" />
      <h3>${game.title}</h3>
      <p>${game.description}</p>
      <p>Цена: ${game.price} ₽</p>
      <button data-id="${game.id}">Купить</button>
    `;
    gamesList.appendChild(card);
  });
}

function updateCart() {
  cartItemsList.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price;
    const li = document.createElement("li");
    li.textContent = `${item.title} — ${item.price} ₽`;
    cartItemsList.appendChild(li);
  });

  totalPriceEl.textContent = total;
  cartCount.textContent = cart.length;
}

gamesList.addEventListener("click", (e) => {
  if (e.target.tagName === "BUTTON") {
    const id = +e.target.dataset.id;
    const game = games.find(g => g.id === id);
    if (game) {
      cart.push(game);
      updateCart();
      alert(`Добавлено в корзину: ${game.title}`);
    }
  }
});

cartButton.addEventListener("click", () => {
  cartSection.classList.toggle("hidden");
});

closeCartBtn.addEventListener("click", () => {
  cartSection.classList.add("hidden");
});

renderGames();
updateCart();
